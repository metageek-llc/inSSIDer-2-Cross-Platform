#! /bin/bash -e
mono /usr/share/inssider/inSSIDer.exe
